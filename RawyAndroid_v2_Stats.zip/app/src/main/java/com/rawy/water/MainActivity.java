package com.rawy.water;

import android.Manifest;
import android.app.TimePickerDialog;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

public class MainActivity extends AppCompatActivity {
    SharedPreferences prefs;
    LinearLayout root, content;
    TextView todayValue, goalValue, progressValue, streakValue, reminderValue;
    int goal;

    final String KEY_TODAY = "today_date";
    final String KEY_WATER = "today_water";
    final String KEY_HISTORY = "history";
    final String KEY_GOAL = "goal";
    final String KEY_ACHIEVEMENTS = "achievements";

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("rawy_prefs", MODE_PRIVATE);
        goal = prefs.getInt(KEY_GOAL, 2000);
        rolloverIfNeeded();
        buildUi();
        updateHome();
        if (Build.VERSION.SDK_INT >= 33 &&
            ActivityCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.POST_NOTIFICATIONS}, 7);
        }
    }

    void buildUi() {
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 28, 28, 36);
        root.setBackgroundColor(Color.WHITE);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        scroll.addView(root);

        TextView title = tv("رَوْي 💧", 30, true);
        root.addView(title, lp());
        TextView sub = tv("لا تنسَ تشرب ماءك", 16, false);
        root.addView(sub, lp());

        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        root.addView(content, lp());

        setContentView(scroll);
    }

    void showHome() {
        content.removeAllViews();
        addHeader("اليوم 💧");
        todayValue = tv("", 42, true);
        todayValue.setTextColor(Color.rgb(22,138,173));
        content.addView(todayValue, lp());

        goalValue = tv("", 17, false); content.addView(goalValue, lp());
        progressValue = tv("", 17, true); content.addView(progressValue, lp());

        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER);
        Button add250 = button("+ 250 مل");
        Button add500 = button("+ 500 مل");
        row.addView(add250, buttonLp()); row.addView(add500, buttonLp());
        content.addView(row, lp());
        add250.setOnClickListener(v -> addWater(250));
        add500.setOnClickListener(v -> addWater(500));

        Button stats = button("📊 الإحصائيات والإنجازات");
        content.addView(stats, lp());
        stats.setOnClickListener(v -> showStats());

        addHeader("التذكير ⏰");
        reminderValue = tv("", 16, false); content.addView(reminderValue, lp());
        Button reminder = button("اختيار وقت التذكير");
        content.addView(reminder, lp());
        reminder.setOnClickListener(v -> chooseReminder());
        Button stop = button("إيقاف التذكير");
        content.addView(stop, lp());
        stop.setOnClickListener(v -> { ReminderScheduler.cancel(this); updateReminder(); });

        addHeader("الإعدادات ⚙️");
        Button goalBtn = button("تغيير الهدف اليومي");
        content.addView(goalBtn, lp());
        goalBtn.setOnClickListener(v -> chooseGoal());

        updateReminder();
    }

    void showStats() {
        content.removeAllViews();
        addHeader("الإحصائيات 📊");

        int today = prefs.getInt(KEY_WATER, 0);
        int[] last7 = getLast7Days();
        int sum = 0, completed = 0;
        for (int x : last7) { sum += x; if (x >= goal) completed++; }

        TextView avg = tv("متوسط آخر 7 أيام: " + (sum / 7) + " مل", 19, true);
        content.addView(avg, lp());
        content.addView(tv("أيام حققت الهدف: " + completed + " / 7", 17, false), lp());

        int streak = calculateStreak();
        TextView st = tv("🔥 السلسلة الحالية: " + streak + " يوم", 21, true);
        st.setTextColor(Color.rgb(22,138,173));
        content.addView(st, lp());

        addHeader("آخر 7 أيام");
        String[] labels = {"اليوم","أمس","-2","-3","-4","-5","-6"};
        for (int i=0;i<7;i++) {
            int pct = goal == 0 ? 0 : Math.min(100, (last7[i]*100)/goal);
            content.addView(tv(labels[i] + ": " + last7[i] + " مل (" + pct + "%)", 16, false), lp());
        }

        addHeader("الإنجازات 🏆");
        addAchievement("💧 أول كوب", prefs.getInt(KEY_WATER,0) > 0 || hasAnyHistory());
        addAchievement("🎯 تحقيق الهدف", hasGoalAchievement());
        addAchievement("🔥 سلسلة 3 أيام", calculateBestStreak() >= 3);
        addAchievement("🏆 سلسلة 7 أيام", calculateBestStreak() >= 7);
        addAchievement("👑 سلسلة 30 يوم", calculateBestStreak() >= 30);

        Button back = button("← العودة للرئيسية");
        content.addView(back, lp());
        back.setOnClickListener(v -> { buildUi(); updateHome(); });
    }

    void addAchievement(String text, boolean unlocked) {
        TextView t = tv((unlocked ? "✅ " : "🔒 ") + text, 17, true);
        t.setPadding(18,18,18,18);
        t.setBackgroundColor(unlocked ? Color.rgb(232,247,252) : Color.rgb(245,245,245));
        content.addView(t, lp());
    }

    void updateHome() {
        if (todayValue == null) { showHome(); return; }
        int water = prefs.getInt(KEY_WATER, 0);
        todayValue.setText(water + " مل");
        goalValue.setText("هدفك اليوم: " + goal + " مل");
        int pct = goal == 0 ? 0 : Math.min(100, water * 100 / goal);
        progressValue.setText("التقدم: " + pct + "%");
        streakValue = tv("",1,false);
        updateReminder();
    }

    void addWater(int amount) {
        rolloverIfNeeded();
        int water = prefs.getInt(KEY_WATER,0) + amount;
        prefs.edit().putInt(KEY_WATER, water).apply();
        saveTodayToHistory();
        if (water >= goal) prefs.edit().putBoolean("goal_ever", true).apply();
        updateHome();
        Toast.makeText(this, "تمت إضافة " + amount + " مل 💧", Toast.LENGTH_SHORT).show();
    }

    void chooseGoal() {
        final EditText input = new EditText(this);
        input.setInputType(2);
        input.setText(String.valueOf(goal));
        new android.app.AlertDialog.Builder(this)
            .setTitle("الهدف اليومي بالمل")
            .setView(input)
            .setPositiveButton("حفظ", (d,w) -> {
                try {
                    int g = Integer.parseInt(input.getText().toString());
                    if (g >= 500 && g <= 10000) {
                        goal = g; prefs.edit().putInt(KEY_GOAL,g).apply(); updateHome();
                    } else Toast.makeText(this,"اختر رقماً بين 500 و10000 مل",Toast.LENGTH_SHORT).show();
                } catch(Exception e) { Toast.makeText(this,"الرقم غير صالح",Toast.LENGTH_SHORT).show(); }
            }).setNegativeButton("إلغاء",null).show();
    }

    void chooseReminder() {
        Calendar c = Calendar.getInstance();
        new TimePickerDialog(this, (v,h,m) -> {
            ReminderScheduler.schedule(this,h,m);
            updateReminder();
            Toast.makeText(this,"تم ضبط التذكير يومياً ⏰",Toast.LENGTH_SHORT).show();
        }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), true).show();
    }

    void updateReminder() {
        if (reminderValue == null) return;
        boolean enabled = prefs.getBoolean(ReminderScheduler.KEY_ENABLED,false);
        if (enabled) {
            reminderValue.setText(String.format(Locale.getDefault(),"التذكير اليومي: %02d:%02d",
                prefs.getInt(ReminderScheduler.KEY_HOUR,10), prefs.getInt(ReminderScheduler.KEY_MINUTE,0)));
        } else reminderValue.setText("التذكير غير مفعّل");
    }

    void rolloverIfNeeded() {
        String today = date(0);
        String saved = prefs.getString(KEY_TODAY, "");
        if (!today.equals(saved)) {
            if (!saved.isEmpty()) {
                String old = prefs.getInt(KEY_WATER,0) + "";
                String hist = prefs.getString(KEY_HISTORY,"");
                if (!hist.isEmpty()) hist += "|";
                hist += saved + ":" + old;
                prefs.edit().putString(KEY_HISTORY, hist).apply();
            }
            prefs.edit().putString(KEY_TODAY,today).putInt(KEY_WATER,0).apply();
        }
    }

    void saveTodayToHistory() {
        // Current day is read directly; previous days are archived at rollover.
    }

    String date(int delta) {
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DAY_OF_YEAR, delta);
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(c.getTime());
    }

    Map<String,Integer> historyMap() {
        Map<String,Integer> m = new HashMap<>();
        String h = prefs.getString(KEY_HISTORY,"");
        if (!h.isEmpty()) for (String item : h.split("\|")) {
            String[] p = item.split(":");
            if (p.length == 2) try { m.put(p[0],Integer.parseInt(p[1])); } catch(Exception ignored){}
        }
        m.put(date(0), prefs.getInt(KEY_WATER,0));
        return m;
    }

    int[] getLast7Days() {
        Map<String,Integer> m = historyMap();
        int[] a = new int[7];
        for (int i=0;i<7;i++) a[i] = m.getOrDefault(date(-i),0);
        return a;
    }

    int calculateStreak() {
        Map<String,Integer> m = historyMap();
        int streak=0;
        // A streak ends on the most recent day that did not reach the goal.
        for (int i=0;i<365;i++) {
            int val = m.getOrDefault(date(-i),0);
            if (val >= goal) streak++;
            else {
                if (i==0) {
                    // If today isn't complete, count completed days ending yesterday.
                    continue;
                }
                break;
            }
        }
        return streak;
    }

    int calculateBestStreak() {
        Map<String,Integer> m = historyMap();
        int best=0, run=0;
        for (int i=364;i>=0;i--) {
            int val = m.getOrDefault(date(-i),0);
            if (val >= goal) { run++; best=Math.max(best,run); }
            else run=0;
        }
        return best;
    }

    boolean hasAnyHistory() {
        return !prefs.getString(KEY_HISTORY,"").isEmpty();
    }

    boolean hasGoalAchievement() {
        return prefs.getBoolean("goal_ever", false);
    }

    TextView tv(String s,int size,boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(Color.rgb(18,52,59));
        t.setGravity(Gravity.CENTER); t.setPadding(8,10,8,10);
        if (bold) t.setTypeface(null, android.graphics.Typeface.BOLD);
        return t;
    }

    void addHeader(String s) {
        TextView h = tv(s,21,true);
        h.setPadding(8,28,8,10);
        h.setTextColor(Color.rgb(22,138,173));
        content.addView(h, lp());
    }

    Button button(String s) {
        Button b = new Button(this); b.setText(s); b.setTextSize(16);
        return b;
    }

    LinearLayout.LayoutParams lp() {
        return new LinearLayout.LayoutParams(-1, -2);
    }

    LinearLayout.LayoutParams buttonLp() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0,-2,1);
        p.setMargins(6,6,6,6); return p;
    }
}
